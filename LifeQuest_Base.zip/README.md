# LIFEQUEST — BASE BUILD

This is the **AI-free foundation** of LifeQuest.

It is deliberately self-contained. There are no API keys, AI services, databases,
external JavaScript libraries, or build tools required.

## EASIEST WAY TO LAUNCH

### Option 1 — Netlify Drop (recommended)
1. Unzip `LifeQuest_Base.zip`.
2. Open the folder named `LifeQuest_Base`.
3. Go to https://app.netlify.com/drop
4. Drag the **entire LifeQuest_Base folder** onto the Netlify Drop area.
5. Netlify will give you a web address.
6. Open that address on your phone.
7. The LifeQuest app should load immediately.

Camera access works on the HTTPS Netlify address.

### Option 2 — Open directly
You can double-click `index.html` on a computer.

The main LifeQuest interface will work, including quests, XP, coins,
progress and local saves.

**Important:** browsers normally block camera/microphone access from a
`file://` page. For Camera/Voice, use Netlify, another HTTPS host, or localhost.

### Option 3 — Local computer server
If Python is installed:

    cd LifeQuest_Base
    python -m http.server 8080

Then open:

    http://localhost:8080

on the same computer.

For phone testing, deploy to HTTPS instead.

## WHAT IS INCLUDED

- Mobile-first LifeQuest interface
- Character level / rank system
- XP progression
- Eight character attributes
- Coins
- Momentum/streak
- Achievements
- Active quest system
- Create your own quests
- Quick Quest generator
- Build/Project shell
- Camera access shell
- Voice quest input where browser support exists
- Inventory
- Home Base
- Base upgrades
- Responsive mobile navigation
- LocalStorage save system
- Offline service worker
- Installable PWA manifest

## WHAT IS INTENTIONALLY NOT INCLUDED

This is the hand-off foundation.

There is **NO AI integration yet**.

The camera currently captures/accesses the phone camera but does not
identify objects. The Build mode creates a project shell but does not
generate an AI project plan. Voice creates a quest from speech where
supported but does not use an AI assistant.

Those are deliberate future integration points.

## FUTURE AI HAND-OFF POINTS

A future version can add:

1. Vision AI
   - identify objects
   - identify tools/materials
   - analyse before/after photos
   - suggest repairs/upcycling

2. Quest AI
   - turn natural language into structured quests
   - break big projects into missions
   - adapt difficulty

3. LifeQuest Companion
   - persistent personality
   - project memory
   - context-aware guidance

4. Location
   - real-world map
   - exploration quests
   - nearby discoveries

5. Evidence
   - photo verification
   - progress recognition
   - achievement validation

6. Cloud account
   - cross-device saves
   - secure authentication
   - backups

## FILE STRUCTURE

    LifeQuest_Base/
      index.html              Main app
      styles.css              Visual design
      app.js                  Game logic and local storage
      manifest.webmanifest    PWA configuration
      sw.js                   Offline caching
      README.md               This guide

## DATA

The current version stores the player's progress in the browser's
LocalStorage.

Clearing browser/site data will remove the local save.

No personal data is sent to an external AI service by this base build.

## HAND-OFF NOTE

Keep this folder as the **base/known-good version**.

A future developer/model can replace or extend the AI-free functions
without having to rebuild the core LifeQuest UI and game loop from scratch.
