const KEY="lifequest-base-v2";
const initial={level:1,xp:120,coins:75,streak:2,base:1,achievements:1,
stats:{Strength:2,Fitness:1,Knowledge:3,Creativity:2,Crafting:4,Money:2,Organisation:2},
inventory:["Phone","Starter Toolkit","Quest Journal"],
quests:[
{id:1,title:"Finish one small job",desc:"Choose something you've been putting off and complete it.",xp:100,coins:25,done:false},
{id:2,title:"Explore your surroundings",desc:"Take a short walk and notice something new.",xp:75,coins:15,done:false},
{id:3,title:"10-minute reset",desc:"Restore one small area of your space.",xp:50,coins:10,done:false}]};
let s;try{s=JSON.parse(localStorage.getItem(KEY))||structuredClone(initial)}catch{s=structuredClone(initial)}
const $=q=>document.querySelector(q);
const esc=x=>String(x).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
function persist(){localStorage.setItem(KEY,JSON.stringify(s));render()}
function rank(){return s.level<3?"The Beginner":s.level<5?"The Maker":s.level<8?"The Pathfinder":s.level<12?"The Builder":"The LifeCrafter"}
function render(){
 const h=new Date().getHours();$("#greeting").textContent=h<12?"Good morning. Your real life is the adventure.":h<18?"Good afternoon. Your next quest is waiting.":"Good evening. Bank another win.";
 const need=s.level*500, pct=Math.min(100,s.xp/need*100);
 $("#levelTag").textContent=`LEVEL ${s.level}`;$("#levelOrb").textContent=s.level;$("#rank").textContent=rank();
 $("#xpLabel").textContent=`${s.xp} / ${need} XP`;$("#xpFill").style.width=pct+"%";
 $("#coins").textContent=s.coins;$("#streak").textContent=s.streak;$("#achievements").textContent=s.achievements;
 $("#statGrid").innerHTML=Object.entries(s.stats).map(([k,v])=>`<div class="stat"><b>${v}</b><small>${k}</small></div>`).join("");
 $("#quests").innerHTML=s.quests.length?s.quests.map(q=>`<article class="quest ${q.done?"done":""}"><div><h3>${q.done?"✓ ":""}${esc(q.title)}</h3><p>${esc(q.desc)}</p><div class="reward">+${q.xp} XP · +${q.coins} 🪙</div></div>${q.done?"<b>✓</b>":`<button onclick="complete(${q.id})">DO IT</button>`}</article>`).join(""):`<div class="empty">No quests yet. Create your first one.</div>`;
 const names=["Starter","Growing","Established","Legendary"];$("#baseTitle").textContent=`${names[Math.min(3,s.base-1)]} Base`;$("#baseDesc").textContent=s.base>=4?"Your headquarters is fully upgraded.":`Base level ${s.base}. ${4-s.base} upgrades remain.`;
}
window.complete=id=>{let q=s.quests.find(x=>x.id===id);if(!q||q.done)return;q.done=true;s.xp+=q.xp;s.coins+=q.coins;s.streak++;s.achievements++;if(q.title.toLowerCase().includes("job"))s.stats.Crafting++;while(s.xp>=s.level*500){s.xp-=s.level*500;s.level++;s.coins+=50;notify("LEVEL UP! 🎉")}persist();notify("Quest complete · +"+q.xp+" XP")};
function notify(t){let e=document.createElement("div");e.textContent=t;e.style.cssText="position:fixed;top:18px;left:50%;transform:translateX(-50%);z-index:99;background:#192337;border:1px solid #73efc066;padding:12px 17px;border-radius:99px;font-weight:900;box-shadow:0 10px 35px #000";document.body.append(e);setTimeout(()=>e.remove(),2200)}
function modal(html){$("#modalBody").innerHTML=html;$("#modal").classList.remove("hidden")}
$("#close").onclick=()=>$("#modal").classList.add("hidden");
$("#newQuest").onclick=()=>modal(`<h2>⚔️ New Quest</h2><p>Create a mission from something you actually want to do.</p><input class="input" id="qt" placeholder="What do you want to accomplish?"><input class="input" id="qd" placeholder="Optional details"><button class="primary" id="create">CREATE QUEST</button>`);
document.addEventListener("click",e=>{if(e.target.id==="create"){let t=$("#qt").value.trim();if(!t)return; s.quests.unshift({id:Date.now(),title:t,desc:$("#qd").value.trim()||"Your custom LifeQuest mission.",xp:100,coins:25,done:false});persist();$("#modal").classList.add("hidden");notify("Quest created.")}});
document.querySelectorAll("[data-action]").forEach(b=>b.onclick=()=>({scan:camera,voice:voice,quick:quick,build:build}[b.dataset.action])());
document.querySelectorAll("[data-zone]").forEach(b=>b.onclick=()=>notify(b.dataset.zone+" discovered."));
$("#questsNav").onclick=()=>document.querySelector("#quests").scrollIntoView({behavior:"smooth",block:"center"});
$("#cameraNav").onclick=camera;
$("#inventoryNav").onclick=()=>modal(`<h2>🎒 Inventory</h2><p>Things your character has discovered or owns.</p>${s.inventory.map(x=>`<div class="result">🔹 ${esc(x)}</div><br>`).join("")}<button class="primary" onclick="document.querySelector('#modal').classList.add('hidden')">CLOSE</button>`);
$("#upgrade").onclick=()=>{if(s.base>=4)return notify("Base is already fully upgraded.");if(s.coins<100)return notify("You need 100 coins.");s.coins-=100;s.base++;s.achievements++;persist();notify("Base upgraded! 🏠")};
function quick(){const q=["Clear one surface","Put five things away","Walk for 10 minutes","Learn one new thing","Message someone you care about","Drink a glass of water"];const x=q[Math.floor(Math.random()*q.length)];modal(`<h2>⚡ Quick Quest</h2><div class="result"><h3>${x}</h3><p>Small action. Real progress.</p><b>+50 XP · +10 🪙</b></div><br><button class="primary" id="accept">ACCEPT QUEST</button>`);$("#accept").onclick=()=>{s.quests.unshift({id:Date.now(),title:x,desc:"Generated as a quick real-world mission.",xp:50,coins:10,done:false});persist();$("#modal").classList.add("hidden")}}
function build(){modal(`<h2>🛠️ Build Mode</h2><p>Describe something you want to make, fix or improve. This base version creates the project shell without AI.</p><input class="input" id="pn" placeholder="e.g. Fix my speaker"><button class="primary" id="make">CREATE PROJECT</button>`);$("#make").onclick=()=>{let x=$("#pn").value.trim();if(!x)return;s.quests.unshift({id:Date.now(),title:x,desc:"Project phase 1: inspect, plan and gather what you need.",xp:150,coins:35,done:false});persist();$("#modal").classList.add("hidden");notify("Project created.")}}
function voice(){if(!("SpeechRecognition"in window||"webkitSpeechRecognition"in window)){return modal(`<h2>🎙️ Voice Quest</h2><p>This browser does not expose speech recognition. Use New Quest instead.</p><button class="primary" onclick="document.querySelector('#modal').classList.add('hidden')">CLOSE</button>`)}const R=window.SpeechRecognition||window.webkitSpeechRecognition,r=new R();r.lang="en-IE";r.interimResults=false;modal("<h2>🎙️ Voice Quest</h2><p>Speak your mission…</p><div class='result'>Listening…</div>");r.onresult=e=>{let t=e.results[0][0].transcript;modal(`<h2>🎙️ Quest detected</h2><div class="result"><h3>${esc(t)}</h3><p>Create this as a quest?</p></div><button class="primary" id="acceptVoice">CREATE QUEST</button>`);$("#acceptVoice").onclick=()=>{s.quests.unshift({id:Date.now(),title:t,desc:"Created by voice.",xp:100,coins:25,done:false});persist();$("#modal").classList.add("hidden")}};r.start()}
async function camera(){modal(`<h2>📸 World Scanner</h2><p>This base build can access the phone camera. AI object recognition is intentionally not connected yet.</p><div class="camera"><video id="video" autoplay playsinline></video><span id="fallback">Camera preview</span></div><button class="primary" id="capture">CREATE SCAN QUEST</button>`);try{let stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment"},audio:false});$("#video").srcObject=stream;$("#fallback").style.display="none";$("#capture").onclick=()=>{stream.getTracks().forEach(x=>x.stop());s.quests.unshift({id:Date.now(),title:"Investigate a scanned object",desc:"Camera evidence captured. Decide what to repair, reuse or transform.",xp:100,coins:25,done:false});persist();$("#modal").classList.add("hidden");notify("Scan quest created.")}}catch(e){$("#fallback").textContent="Camera unavailable here. Deploy over HTTPS or open on localhost to enable it."}}
if("serviceWorker"in navigator)navigator.serviceWorker.register("sw.js").catch(()=>{});
render();